#!/usr/bin/env bash
# Baixa o toolchain Android para dentro de third_party/android (nada no sistema,
# nada no ~/Android, nada de Android Studio ou Gradle). Tudo com versao FIXA:
# quem quiser atualizar troca os numeros aqui, de proposito, e testa.
#
#   SDK cmdline-tools  11076708         (sdkmanager)
#   platforms          android-34       (android.jar para o aapt2)
#   build-tools        34.0.0           (aapt2, zipalign, apksigner)
#   ndk                27.2.12479018    (clang para arm64/arm/x86_64)
#   platform-tools     (adb)            opcional, para instalar e ver o logcat
#
# Precisa de Java 17 no PATH (o sdkmanager e o apksigner sao .jar):
#   Fedora/Nobara: sudo dnf install java-17-openjdk-headless
#   Debian/Ubuntu: sudo apt install openjdk-17-jdk-headless
# Espaco: ~2,5 GB.  Uso: bash android/fetch-android.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TP="$ROOT/third_party/android"
SDK="$TP/sdk"
CLT_VER="${REMIX_ANDROID_CLT:-11076708}"
PLATFORM="${REMIX_ANDROID_PLATFORM:-android-34}"
BUILD_TOOLS="${REMIX_ANDROID_BUILD_TOOLS:-34.0.0}"
NDK_VER="${REMIX_ANDROID_NDK:-27.2.12479018}"
mkdir -p "$SDK"

command -v java >/dev/null || { echo "[android] Java 17 nao encontrado no PATH (veja o cabecalho do script)"; exit 1; }
JV="$(java -version 2>&1 | head -1 | sed -E 's/.*"([0-9]+).*/\1/')"
[ "$JV" -ge 17 ] 2>/dev/null || echo "[android] aviso: Java $JV; o sdkmanager pede 17+"

if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "[android] baixando cmdline-tools $CLT_VER..."
  curl -sSL --retry 3 -o "$TP/clt.zip" "https://dl.google.com/android/repository/commandlinetools-linux-${CLT_VER}_latest.zip"
  rm -rf "$TP/clt"; mkdir -p "$TP/clt"; (cd "$TP/clt" && unzip -q "$TP/clt.zip")
  mkdir -p "$SDK/cmdline-tools"; rm -rf "$SDK/cmdline-tools/latest"; mv "$TP/clt/cmdline-tools" "$SDK/cmdline-tools/latest"
  rm -rf "$TP/clt" "$TP/clt.zip"
fi
SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"
# aceita as licencas uma vez (fica em third_party/android/sdk/licenses)
yes | "$SDKM" --sdk_root="$SDK" --licenses >/dev/null 2>&1 || true
echo "[android] instalando platforms;$PLATFORM build-tools;$BUILD_TOOLS ndk;$NDK_VER platform-tools ..."
"$SDKM" --sdk_root="$SDK" "platforms;$PLATFORM" "build-tools;$BUILD_TOOLS" "ndk;$NDK_VER" "platform-tools" | grep -v '^\[=' || true

# raylib (o mesmo fonte que o Linux usa)
[ -d "$ROOT/third_party/raylib-5.5/src" ] || bash "$ROOT/linux/fetch-deps.sh"

# keystore de desenvolvimento (so para instalar no seu aparelho; a loja usa outra, fora do git)
KS="$TP/debug.keystore"
if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -alias remix -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass android -keypass android -dname "CN=Remix Player, O=EchoGroupStudio" >/dev/null 2>&1
  echo "[android] keystore de desenvolvimento criada: $KS"
fi
echo "[android] ok. Agora: bash android/build-android.sh"
