// Remix Player — casca Android (raylib + miniaudio), ESQUELETO.
// A logica esta em comum/ (app_core.h, app_input.h...); o desenho e o mesmo do Linux
// (linux/app_draw*.h, linux/gfx.h). Aqui ficam so: laco principal com toque,
// densidade da tela, pastas do Android e os ganchos Platform* que dependem da janela.
// Compare com linux/main_linux.cpp: as chamadas do laco sao as mesmas.
#include "app_draw2.h"     // linux/ (raylib) -> inclui app_state.h -> sys_android.h (via __ANDROID__)
#include "app_input.h"
#include <clocale>
#include <cmath>

// ------------------------------------------------ capas (igual ao Linux) -----
static bool ImageHasTransparency(Image& img){
    if(img.format!=PIXELFORMAT_UNCOMPRESSED_R8G8B8A8 && img.format!=PIXELFORMAT_UNCOMPRESSED_GRAY_ALPHA &&
       img.format!=PIXELFORMAT_UNCOMPRESSED_R5G5B5A1 && img.format!=PIXELFORMAT_UNCOMPRESSED_R4G4B4A4) return false;
    ImageFormat(&img,PIXELFORMAT_UNCOMPRESSED_R8G8B8A8);
    Color* px=(Color*)img.data; size_t n=(size_t)img.width*img.height;
    for(size_t i=0;i<n;i++) if(px[i].a<255) return true;
    return false;
}
static bool SaveResized(Image img,const std::wstring& dest,bool png){
    int w=img.width,h=img.height; if(w<=0||h<=0) return false;
    double sc=(double)COVER_MAX_DIM/(double)(w>h?w:h);
    int nw=std::max(1,(int)std::floor(w*sc)), nh=std::max(1,(int)std::floor(h*sc));
    Image copy=ImageCopy(img);
    ImageFormat(&copy,PIXELFORMAT_UNCOMPRESSED_R8G8B8A8);
    ImageResize(&copy,nw,nh);
    if(!png) ImageFormat(&copy,PIXELFORMAT_UNCOMPRESSED_R8G8B8);
    bool ok=ExportImage(copy,WideToUtf8(dest).c_str());
    UnloadImage(copy);
    return ok;
}
std::wstring ShrinkCoverInto(const std::wstring& dir,const wchar_t* name,const std::wstring& imgPath){
    Image img=LoadImage(WideToUtf8(imgPath).c_str());
    if(!img.data) return L"";
    int w=img.width,h=img.height;
    if(w<=0||h<=0||(w<=COVER_MAX_DIM&&h<=COVER_MAX_DIM)){ UnloadImage(img); return L""; }
    bool alpha=ImageHasTransparency(img);
    std::wstring dest=Config::Join(dir,std::wstring(name)+(alpha?L".png":L".jpg"));
    bool ok=SaveResized(img,dest,alpha);
    UnloadImage(img);
    return ok?dest:L"";
}

// ------------------------------------------------ ganchos de janela ----------
// No Android a janela e a tela inteira: nada de redimensionar/minimizar/esconder.
static bool g_quit=false;
static std::wstring g_shotPath; static bool g_shotPending=false;
void PlatformResizeForMode(){ g_listScroll=0; g_setScroll=0; g_winW=GetScreenWidth(); g_winH=GetScreenHeight(); BuildLayout(); }
void PlatformMinimize(){}
void PlatformClose(){ g_quit=true; }
void PlatformRestoreAndFocus(){ BuildLayout(); }
void PlatformHide(){}                    // "fechar continua tocando": o Android decide (fase 2: servico)
void PlatformSetWindowSize(int,int){}
bool PlatformScreenshot(const std::wstring& png){ g_shotPath=png; g_shotPending=true; return true; }
void PlatformUpdateGlobalHotkeys(){}     // nao existe atalho global no Android
int MigrateOversizedCovers(){ return 0; }

static void Render(){
    int w=g_winW,h=g_winH;
    if(g_showSplash){DrawSplash(w,h);return;}
    if(g_cfg.displayMode==L"vertical")DrawVertical(w,h);else DrawNormal(w,h);
    if(g_imgMenuOpen)DrawImgMenu(w,h);
    if(OU().open)DrawOnline(w,h);
    if(g_folderMenuOpen)DrawFolderMenu(w,h);
    if(g_ctxOpen)DrawCtxMenu(w,h);
    if(g_editArtist)DrawArtistEditor(w,h);
    if(WP().open){LayoutWebPick(w,h);DrawWebPick(w,h);}
    if(g_confirmOpen)DrawConfirm(w,h);
    DrawActivity(w,h);
    DrawStatusToast(w,h);
}
// Zonas que sao "arrastar" (seek, volume, sliders): o toque vai direto para o clique,
// para o arrasto funcionar; no resto, arrastar rola a lista e soltar sem arrastar clica.
static bool ZonaDeArrasto(int z){
    if(z==Z_SEEKBAR||z==Z_VOLBAR||z==Z_WAVESEEK||z==Z_PLAYER_RESIZE) return true;
    if(z>=Z_CARD_SEEK_BASE&&z<Z_CARD_SEEK_BASE+1000000) return true;
    for(auto&s:g_setSliders) if(s.id==z) return true;
    return false;
}
// Orientacao: em pe = vertical, deitado = normal (mesmo layout do desktop).
static void AjustarOrientacao(){
    int w=GetScreenWidth(),h=GetScreenHeight();
    std::wstring want=(h>w)?L"vertical":L"normal";
    if(g_cfg.displayMode!=want){ g_cfg.displayMode=want; if(want==L"normal"&&g_cfg.artShape!=L"square"&&g_cfg.artShape!=L"cd") g_cfg.artShape=L"square"; }
    if(w!=g_winW||h!=g_winH){ g_winW=w; g_winH=h; BuildLayout(); }
}

int main(int argc,char** argv){
    (void)argc;(void)argv;
    setlocale(LC_ALL,"C.UTF-8");
    android_app* app=GetAndroidApp();
    // pastas: config/biblioteca/capas na area interna do app; assets copiados do APK
    setenv("REMIX_HOME",app->activity->internalDataPath,1);
    std::string assets=sys::ExtractAssets(WideToUtf8(REMIX_VERSAO).c_str());
    setenv("REMIX_ASSETS",assets.c_str(),1);
    setenv("HOME","/storage/emulated/0",0);
    sys::InitProcess();
    g_cfg.Load();
    if(g_cfg.musicFolder.empty()) g_cfg.musicFolder=L"/storage/emulated/0/Music";   // fase 2: SAF
    g_dpiMul=sys::ScreenDensityScale();
    if(!sys::HasPermission(sys::AudioPermissionName())) sys::RequestPermission(sys::AudioPermissionName());
    CoreInit();
    g_customChrome=false;

    SetTraceLogLevel(LOG_WARNING);
    SetConfigFlags(FLAG_VSYNC_HINT);
    InitWindow(0,0,"Remix Player");           // Android: tela inteira, o tamanho vem do sistema
    SetExitKey(0); SetTargetFPS(g_cfg.perfMode?30:60);
    gfx::InitFonts(Config::AssetDir());
    g_splashImg=gfx::LoadImg(Config::Join(Config::Join(Config::AssetDir(),L"branding"),L"splash.png"));
    if(!g_splashImg->ok){ gfx::FreeImg(g_splashImg); g_splashImg=nullptr; }
    g_splashStart=GetTickCount64(); g_showSplash=false;
    AjustarOrientacao(); PlatformResizeForMode();

    // toque: arrastar = rolar; soltar parado = clique; zonas de arrasto = clique imediato
    bool tDown=false,tDrag=false,tImediato=false; Vector2 t0{0,0}; float acc=0;
    ULONGLONG t0ms=GetTickCount64(); ULONGLONG last=t0ms;
    while(!WindowShouldClose()&&!g_quit){
        ULONGLONG now=GetTickCount64(); float dt=(float)(now-last)/1000.f; last=now; if(dt>0.1f)dt=0.1f;
        AjustarOrientacao();
        { sys::Ev ev; while(sys::Poll(ev)) HandleEvent(ev.type,ev.s,ev.n); }
        Tick(dt);
        RunTimedActions(now-t0ms);
        Vector2 mp=GetMousePosition(); int mx=(int)mp.x,my=(int)mp.y; g_mouseX=mx; g_mouseY=my;
        if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)){
            tDown=true; tDrag=false; t0=mp; acc=0;
            tImediato=ZonaDeArrasto(HitTest(mx,my));
            if(tImediato) OnLButtonDown(mx,my);
        } else if(tDown&&IsMouseButtonDown(MOUSE_BUTTON_LEFT)){
            if(tImediato){ if(g_dragSeek!=-1) OnMouseDrag(mx); }
            else {
                float dy=mp.y-t0.y;
                if(!tDrag&&fabsf(dy)>S(10)) tDrag=true;
                if(tDrag){ acc+=dy; int passo=(int)S(36); while(acc>=passo){ OnWheel(+1); acc-=passo; } while(acc<=-passo){ OnWheel(-1); acc+=passo; } t0=mp; }
            }
        }
        if(IsMouseButtonReleased(MOUSE_BUTTON_LEFT)&&tDown){
            if(tImediato) OnLButtonUp();
            else if(!tDrag){ OnLButtonDown(mx,my); OnLButtonUp(); }
            tDown=false; tDrag=false; tImediato=false;
        }
        // toque longo = botao direito (menu de contexto): fase 2
        if(IsKeyPressed(KEY_BACK)) OnKeyEvent(KC_ESC,0);
        for(int c=GetCharPressed();c;c=GetCharPressed()) OnChar(c);
        BeginDrawing();
        Render();
        EndDrawing();
        if(g_shotPending){ g_shotPending=false; TakeScreenshot(WideToUtf8(g_shotPath).c_str()); }
        g_mouseX=tDown?mx:-9999; g_mouseY=tDown?my:-9999;   // sem mouse: "hover" so enquanto o dedo esta na tela
    }
    g_cfg.Save();
    CoreShutdown();
    CloseWindow();
    return 0;
}
